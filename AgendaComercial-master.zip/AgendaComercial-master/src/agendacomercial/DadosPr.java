
package agendacomercial;


public class DadosPr {
    int id_profi;
    String empresa;
    String cargo;
    int fk;
}

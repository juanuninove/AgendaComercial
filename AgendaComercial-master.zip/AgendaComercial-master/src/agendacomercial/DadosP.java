
package agendacomercial;


public class DadosP {
   int id_dados;
   String nome, sobrenome, n_social;
   String d_nasc, idioma;
}

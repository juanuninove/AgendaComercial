

package agendacomercial;

public class Email {
   int id_mail;
   String email;
   String tipo;
   int fk;
}
